"use client";

import { useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";

type Screen =
  | "welcome"
  | "signup"
  | "connect"
  | "home"
  | "create"
  | "people"
  | "windows"
  | "deadline"
  | "poll"
  | "results"
  | "confirmed"
  | "notifications"
  | "calendars";

const people = [
  { name: "Саша", letter: "С", color: "coral", hex: "#ff314a", ring: "#ff8996" },
  { name: "Макс", letter: "М", color: "gold", hex: "#f0bd00", ring: "#ffe070" },
  { name: "Глеб", letter: "Г", color: "blue", hex: "#2448ff", ring: "#8295ff" },
  { name: "Костя", letter: "К", color: "pink", hex: "#ed00c5", ring: "#ff78de" },
  { name: "Валера", letter: "В", color: "green", hex: "#00cf73", ring: "#78efb5" },
];

const profileColors = [
  { name: "Фиолетовый", hex: "#8f68ff", soft: "#cbbaff", rgb: "143,104,255" },
  { name: "Синий", hex: "#3975ff", soft: "#9db8ff", rgb: "57,117,255" },
  { name: "Коралловый", hex: "#ff5967", soft: "#ffadb4", rgb: "255,89,103" },
  { name: "Зелёный", hex: "#16c978", soft: "#87e8b7", rgb: "22,201,120" },
];

const groups = [
  { name: "jungariki", className: "group-one", members: [0, 1, 2] },
  { name: "TG-4", className: "group-two", members: [0, 1, 2, 3] },
  { name: "CINEMA", className: "group-three", members: [2, 3, 4] },
];

const upcomingEvents = [
  {
    title: "Дабл по боулингу",
    subtitle: "с Глебом и Костей",
    day: "Сегодня",
    date: "17 августа",
    time: "19:00—21:00",
    place: "Lucky Strike",
    participants: [2, 3, 0, 1],
    gradient: "radial-gradient(circle at 22% 18%, #2448ff 0, transparent 34%), radial-gradient(circle at 82% 22%, #ed00c5 0, transparent 36%), radial-gradient(circle at 35% 82%, #ff314a 0, transparent 42%), radial-gradient(circle at 78% 82%, #f0bd00 0, transparent 40%), #32005f",
  },
  {
    title: "Караоке",
    subtitle: "на большой сцене",
    day: "Завтра",
    date: "18 августа",
    time: "20:00—23:00",
    place: "Studio 46",
    participants: [3, 4, 1],
    gradient: "radial-gradient(circle at 22% 28%, #ed00c5 0, transparent 38%), radial-gradient(circle at 80% 30%, #00cf73 0, transparent 37%), radial-gradient(circle at 52% 88%, #f0bd00 0, transparent 46%), #171063",
  },
  {
    title: "Завтрак без спешки",
    subtitle: "с Сашей",
    day: "Во вторник",
    date: "19 августа",
    time: "10:30—12:30",
    place: "Кофемания",
    participants: [0, 2],
    gradient: "radial-gradient(circle at 20% 20%, #ff314a 0, transparent 42%), radial-gradient(circle at 78% 42%, #2448ff 0, transparent 44%), radial-gradient(circle at 45% 95%, #7d28ff 0, transparent 50%), #17031d",
  },
];

function mixColors(first: string, second: string) {
  const channels = [1, 3, 5].map((offset) => Math.round((parseInt(first.slice(offset, offset + 2), 16) + parseInt(second.slice(offset, offset + 2), 16)) / 2));
  return `#${channels.map((channel) => channel.toString(16).padStart(2, "0")).join("")}`;
}

function colorWithAlpha(color: string, alpha: number) {
  const channels = [1, 3, 5].map((offset) => parseInt(color.slice(offset, offset + 2), 16));
  return `rgba(${channels.join(",")},${alpha})`;
}

function eventGradient(participants: number[]) {
  if (!participants.length) return "#160021";

  const colors = participants.map((personIndex) => people[personIndex].hex);
  const segment = 100 / colors.length;
  const softStops = colors.flatMap((color, index) => {
    const nextColor = colors[(index + 1) % colors.length];
    const start = index * segment;
    const middle = start + segment / 2;
    return [`${color} ${start}%`, `${mixColors(color, nextColor)} ${middle}%`];
  });
  softStops.push(`${colors[0]} 100%`);

  const overlappingColorClouds = colors.map((color, index) => {
    const angle = -90 + (360 / colors.length) * index;
    const x = 50 + Math.cos((angle * Math.PI) / 180) * 34;
    const y = 44 + Math.sin((angle * Math.PI) / 180) * 34;
    return `radial-gradient(ellipse 72% 82% at ${x.toFixed(1)}% ${y.toFixed(1)}%, ${colorWithAlpha(color, .82)} 0%, ${colorWithAlpha(color, .42)} 38%, transparent 72%)`;
  }).join(", ");

  return `radial-gradient(circle at 50% 44%, rgba(255,255,255,.28) 0%, rgba(255,255,255,.1) 16%, transparent 38%), radial-gradient(circle at 50% 44%, transparent 0%, rgba(8,4,18,.08) 47%, rgba(3,2,8,.5) 100%), ${overlappingColorClouds}, conic-gradient(from -90deg at 50% 44%, ${softStops.join(", ")})`;
}

const routes: { id: Screen; label: string }[] = [
  { id: "welcome", label: "Вход" },
  { id: "home", label: "Главная" },
  { id: "create", label: "Новая встреча" },
  { id: "poll", label: "Ответ" },
  { id: "results", label: "Результаты" },
  { id: "confirmed", label: "Готово" },
];

function IconButton({ label, children, onClick }: { label: string; children: React.ReactNode; onClick?: () => void }) {
  return <button className="icon-button" aria-label={label} onClick={onClick}>{children}</button>;
}

function Header({ title, onBack, right }: { title?: string; onBack?: () => void; right?: React.ReactNode }) {
  return (
    <header className="app-header">
      <div className="header-side">{onBack && <IconButton label="Назад" onClick={onBack}>‹</IconButton>}</div>
      <div className="header-title">{title}</div>
      <div className="header-side header-right">{right}</div>
    </header>
  );
}

function BrandMark() {
  return <div className="brand-mark" aria-label="Druna">ü</div>;
}

function PersonAvatar({ person, selected = false, small = false }: { person: typeof people[number]; selected?: boolean; small?: boolean }) {
  const background = selected
    ? `linear-gradient(${person.hex}, ${person.hex}) padding-box, conic-gradient(from 20deg, ${person.hex}, ${person.ring}, ${person.hex}) border-box`
    : person.hex;
  return (
    <div className={`avatar-wrap ${selected ? "selected" : ""}`}>
      <div className={`avatar ${small ? "small" : ""}`} style={{ background, borderColor: "transparent", boxShadow: selected ? `0 0 18px ${person.ring}55` : undefined }}>{person.letter}</div>
      {!small && <span>{person.name}</span>}
    </div>
  );
}

function StatusBar() {
  return <div className="status-bar"><b>9:41</b><span>● ● ▰</span></div>;
}

function BottomHandle() {
  return <div className="bottom-handle" />;
}

function Welcome({ go }: { go: (s: Screen) => void }) {
  const [mode, setMode] = useState<"start" | "login">("start");
  return (
    <div className="screen auth-screen">
      <StatusBar />
      <div className="auth-content">
        <BrandMark />
        <div className="auth-heading">
          <p className="eyebrow">DRUNA</p>
          <h1>{mode === "start" ? "Найдём время\nдля встречи" : "С возвращением"}</h1>
          <p className="muted auth-copy">Сверим календари и покажем удобные окна</p>
        </div>
        {mode === "login" ? (
          <div className="form-stack">
            <label className="field"><span>Ник или почта</span><input defaultValue="jokerbubliko@gmail.com" /></label>
            <label className="field"><span>Пароль</span><input type="password" defaultValue="drunapass" /></label>
            <button className="primary" onClick={() => go("home")}>Войти</button>
            <button className="text-button">Не помню пароль</button>
          </div>
        ) : (
          <div className="form-stack">
            <button className="primary" onClick={() => setMode("login")}>Войти</button>
            <button className="secondary" onClick={() => go("signup")}>Создать аккаунт</button>
            <button className="guest-link" onClick={() => go("poll")}>Ответить на приглашение без аккаунта →</button>
          </div>
        )}
      </div>
      <BottomHandle />
    </div>
  );
}

function Signup({ go, assignProfileColor }: { go: (s: Screen) => void; assignProfileColor: () => void }) {
  return (
    <div className="screen signup-screen">
      <StatusBar />
      <Header title="Создать аккаунт" onBack={() => go("welcome")} />
      <main className="page-body auth-form-page">
        <div className="progress"><i className="active"/><i/><i/></div>
        <div><h2>Создать профиль</h2><p className="muted">После регистрации Druna автоматически назначит твой постоянный цвет</p></div>
        <div className="form-stack">
          <label className="field"><span>Почта</span><input placeholder="you@example.com" /></label>
          <label className="field"><span>Ник</span><input placeholder="Как тебя найдут друзья" /></label>
          <label className="field"><span>Пароль</span><input type="password" placeholder="Минимум 8 символов" /></label>
        </div>
        <div className="push-bottom">
          <button className="primary" onClick={() => { assignProfileColor(); go("connect"); }}>Создать профиль</button>
          <p className="legal">Продолжая, ты принимаешь условия</p>
        </div>
      </main>
      <BottomHandle />
    </div>
  );
}

function ConnectCalendars({ go }: { go: (s: Screen) => void }) {
  const [connected, setConnected] = useState<string[]>(["Apple Calendar"]);
  const toggle = (name: string) => setConnected(v => v.includes(name) ? v.filter(x => x !== name) : [...v, name]);
  return (
    <div className="screen gradient-top">
      <StatusBar />
      <Header title="Твои календари" onBack={() => go("signup")} />
      <main className="page-body">
        <div className="hero-orbit"><BrandMark /><span className="orbit one"/><span className="orbit two"/></div>
        <div className="center-copy">
          <h2>Подключи календари</h2>
          <p className="muted">Друзья увидят только свободное время</p>
        </div>
        <div className="calendar-connect-list">
          {[{name:"Apple Calendar", icon:""},{name:"Google Calendar", icon:"G"},{name:"Outlook", icon:"O"}].map(item => (
            <button className="connect-row" key={item.name} onClick={() => toggle(item.name)}>
              <span className="provider-icon">{item.icon}</span><span>{item.name}</span>
              <span className={`switch ${connected.includes(item.name) ? "on" : ""}`}><i/></span>
            </button>
          ))}
        </div>
        <div className="push-bottom">
          <button className="primary" onClick={() => go("home")}>Продолжить</button>
          <button className="text-button" onClick={() => go("home")}>Пока пропустить</button>
        </div>
      </main>
      <BottomHandle />
    </div>
  );
}

function Home({ go }: { go: (s: Screen) => void }) {
  const [activeEvent, setActiveEvent] = useState(0);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [dragStart, setDragStart] = useState<number | null>(null);
  const event = upcomingEvents[activeEvent];

  useEffect(() => {
    if (sheetOpen || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setTimeout(() => {
      setActiveEvent((current) => (current + 1) % upcomingEvents.length);
    }, 7000);
    return () => window.clearTimeout(timer);
  }, [activeEvent, sheetOpen]);

  const selectEvent = (index: number) => {
    setActiveEvent(index);
    setSheetOpen(false);
  };

  return (
    <div className="screen home-event-screen">
      <div className="event-gradient" style={{ background: eventGradient(event.participants) }} />
      <StatusBar />
      <header className="event-home-header">
        <span className="day-button">Вс</span>
        <div className="event-pager" aria-label="Ближайшие события">
          {upcomingEvents.map((item, index) => (
            <button
              key={item.title}
              className={index === activeEvent ? "active" : ""}
              onClick={() => selectEvent(index)}
              aria-label={`Открыть событие ${item.title}`}
            />
          ))}
          <button className="pager-add" onClick={() => go("create")} aria-label="Создать событие">+</button>
        </div>
        <div className="event-header-actions">
          <IconButton label="Уведомления" onClick={() => go("notifications")}>◔<b className="badge">2</b></IconButton>
          <IconButton label="Настройки" onClick={() => go("calendars")}>⚙</IconButton>
        </div>
      </header>

      <main className="event-focus">
        <div className="event-orbit" aria-label={`Событие ${event.title}`}>
          <div className="event-core">
            <p className="event-day">{event.day}</p>
            <h1>{event.title}<span>{event.subtitle}</span></h1>
          </div>
          {event.participants.map((personIndex, position) => {
            const angle = -90 + (360 / event.participants.length) * position;
            const radius = event.participants.length > 5 ? 120 : event.participants.length > 3 ? 112 : 100;
            const person = people[personIndex];
            return (
              <div
                className="orbit-person"
                key={person.name}
                style={{ transform: `translate(-50%, -50%) rotate(${angle}deg) translateY(-${radius}px) rotate(${-angle}deg)` }}
              >
                <span style={{ background: `linear-gradient(${person.hex}, ${person.hex}) padding-box, conic-gradient(from 20deg, ${person.hex}, ${person.ring}, ${person.hex}) border-box`, borderColor: "transparent", boxShadow: `0 0 20px ${person.ring}55, 0 10px 28px rgba(0,0,0,.3)` }}>{person.letter}</span>
                <small>{person.name}</small>
              </div>
            );
          })}
        </div>
        <div className="event-when">
          <strong>{event.time}</strong>
          <span>{event.date}</span>
          <span>{event.place}</span>
        </div>
      </main>

      <section className={`event-sheet ${sheetOpen ? "open" : ""}`}>
        <button
          className="sheet-grabber"
          onClick={() => setSheetOpen(value => !value)}
          aria-label={sheetOpen ? "Свернуть события" : "Показать события"}
          aria-expanded={sheetOpen}
        onPointerDown={(e) => setDragStart(e.clientY)}
        onPointerUp={(e) => {
          if (dragStart === null) return;
          const distance = e.clientY - dragStart;
          if (distance < -24) setSheetOpen(true);
          if (distance > 24) setSheetOpen(false);
          setDragStart(null);
        }}
        ><span /></button>
        <div className="sheet-scroll">
          <div className="sheet-heading"><div><small>БЛИЖАЙШИЕ</small><h2>Твои события</h2></div></div>
          <div className="event-rail">
            {upcomingEvents.map((item, index) => (
              <button className={`event-tile ${index === activeEvent ? "active" : ""}`} key={item.title} onClick={() => selectEvent(index)} style={{ background: eventGradient(item.participants) }}>
                <span>{item.day}</span><strong>{item.title}</strong><small>{item.time}</small>
              </button>
            ))}
            <button className="event-tile create-tile" onClick={() => go("create")}><b>＋</b><strong>Создать</strong><small>Найти общее время</small></button>
          </div>

          <div className="airy-section">
            <div className="sheet-heading"><h3>Друзья</h3><span>{people.length}</span></div>
            <div className="people-row">{people.map((person, index) => <button key={index}><PersonAvatar person={person}/></button>)}</div>
          </div>

          <div className="airy-section groups-section">
            <div className="sheet-heading"><h3>Группы</h3><span>3</span></div>
            <div className="group-row">
              {groups.map((group) => <button className={`group-tile ${group.className}`} key={group.name} onClick={() => go("create")}><b>{group.name[0]}</b><span>{group.name}</span></button>)}
              <button className="group-tile group-add" onClick={() => go("create")}><b>＋</b><span>Добавить</span></button>
            </div>
          </div>
        </div>
      </section>
      <BottomHandle />
    </div>
  );
}

function StepShell({ title, step, back, children }: { title: string; step: number; back: () => void; children: React.ReactNode }) {
  return <div className="screen step-screen"><StatusBar/><Header title={title} onBack={back}/><div className="step-progress" aria-label={`Шаг ${step} из 4`}>{[1,2,3,4].map(item => <i key={item} className={`${item < step ? "done" : ""} ${item === step ? "current" : ""}`}/>)}</div>{children}<BottomHandle/></div>;
}

function CreateMeeting({ go }: { go: (s: Screen) => void }) {
  const [duration, setDuration] = useState(2);
  return (
    <StepShell title="Новая встреча" step={1} back={() => go("home")}>
      <main className="page-body create-page">
        <div><h2>Что планируем?</h2><p className="muted">Основные детали можно изменить позже</p></div>
        <label className="field"><span>Название</span><input defaultValue="Дабл по боулингу" /></label>
        <label className="field"><span>Подпись</span><input defaultValue="Собираемся своей компанией" /></label>
        <label className="field"><span>Место</span><input defaultValue="Lucky Strike" /></label>
        <div className="field-row">
          <label className="field"><span>Дата</span><input defaultValue="20 августа" /></label>
          <label className="field"><span>Время</span><input defaultValue="19:00" /></label>
        </div>
        <div><p className="field-label">Продолжительность</p><div className="chips duration-chips">{[1,2,3,4].map(hours=><button key={hours} className={duration===hours?"active":""} aria-pressed={duration===hours} onClick={()=>setDuration(hours)}>{hours} {hours===1?"час":"часа"}</button>)}</div></div>
        <label className="field tall"><span>Заметка</span><textarea defaultValue="После боулинга можно взять пиццу" /></label>
        <div className="push-bottom"><button className="primary" onClick={() => go("people")}>Выбрать участников</button></div>
      </main>
    </StepShell>
  );
}

function SelectPeople({ go }: { go: (s: Screen) => void }) {
  const [selected, setSelected] = useState([0,1,2,3]);
  const [selectedGroup, setSelectedGroup] = useState("TG-4");
  const toggle = (i:number) => {
    setSelectedGroup("");
    setSelected(s => s.includes(i) ? s.filter(x=>x!==i) : [...s,i]);
  };
  const chooseGroup = (name: string, members: number[]) => {
    setSelectedGroup(name);
    setSelected(members);
  };
  return (
    <StepShell title="Участники" step={2} back={() => go("create")}>
      <main className="page-body">
        <div><h2>Кого позвать?</h2><p className="muted">Выбери готовую группу или собери новую</p></div>
        <div className="participant-groups">
          {groups.map((group) => (
            <button className={selectedGroup === group.name ? "active" : ""} key={group.name} onClick={() => chooseGroup(group.name, group.members)}>
              <span className={group.className}>{group.name[0]}</span>
              <b>{group.name}</b>
              <small>{group.members.length} человека</small>
            </button>
          ))}
          <button className={!selectedGroup ? "active new-group" : "new-group"} onClick={() => { setSelectedGroup(""); setSelected([]); }}>
            <span>＋</span><b>Собрать группу</b><small>Выбрать вручную</small>
          </button>
        </div>
        {!selectedGroup && <label className="field"><span>Название группы</span><input placeholder="Например, Команда" /></label>}
        <label className="search-field">⌕<input placeholder="Найти друга или группу"/></label>
        <div className="selected-strip">{selected.map(i=><PersonAvatar key={i} person={people[i]} selected />)}<button className="invite-avatar"><span>↗</span><small>Ссылка</small></button></div>
        <div className="list-block">
          <p className="field-label">Друзья</p>
          {people.map((p,i)=><button className={`person-row ${selected.includes(i)?"selected":""}`} key={i} onClick={()=>toggle(i)}><PersonAvatar person={p} small/><span><b>{p.name}</b><small>@{["slavaaaa","mc_max","gleg","djko","valera"][i]}</small></span></button>)}
        </div>
        <div className="push-bottom"><button className="primary" onClick={() => go("windows")}>Продолжить</button></div>
      </main>
    </StepShell>
  );
}

function PickWindows({ go }: { go: (s: Screen) => void }) {
  const [picked, setPicked] = useState([1,2,4]);
  const slots = ["Пн 18   18:00–22:00","Вт 19   17:00–21:00","Ср 20   18:30–23:00","Пт 22   19:00–23:00","Сб 23   14:00–20:00"];
  return (
    <StepShell title="Варианты времени" step={3} back={() => go("people")}>
      <main className="page-body compact">
        <div><h2>Выбери варианты</h2><p className="muted">Можно отметить несколько диапазонов</p></div>
        <div className="week-strip">{["Пн","Вт","Ср","Чт","Пт","Сб","Вс"].map((d,i)=><button className={i===1||i===2||i===5?"active":""} key={d}><span>{d}</span><b>{18+i}</b></button>)}</div>
        <div className="range-list">{slots.map((slot,i)=><button key={slot} className={picked.includes(i)?"picked":""} onClick={()=>setPicked(p=>p.includes(i)?p.filter(x=>x!==i):[...p,i])}><span>{slot}</span><small>{i===2?"Все свободны":"3–4 свободны"}</small></button>)}</div>
        <button className="add-range">＋ Добавить другой диапазон</button>
        <div className="push-bottom"><button className="primary" onClick={() => go("deadline")}>Настроить опрос</button></div>
      </main>
    </StepShell>
  );
}

function Deadline({ go }: { go: (s: Screen) => void }) {
  const [auto, setAuto] = useState(true);
  return (
    <StepShell title="Настройки опроса" step={4} back={() => go("windows")}>
      <main className="page-body">
        <div><h2>Завершение опроса</h2><p className="muted">Укажи, когда выбирать лучшее время</p></div>
        <button className="date-setting"><span><small>Дедлайн</small><b>Сегодня, 20:00</b></span><strong>›</strong></button>
        <div className="setting-card">
          <div><b>Автоматически выбрать время</b><p>Druna выберет лучший слот после дедлайна и даст тебе 30 минут на проверку</p></div>
          <button className={`switch ${auto?"on":""}`} onClick={()=>setAuto(!auto)}><i/></button>
        </div>
        <div className="answer-legend"><p>Могу <span>× 3</span></p><p>Не могу <span>× 1</span></p></div>
        <div className="summary-card"><p><span>Встреча</span><b>Дабл по боулингу</b></p><p><span>Участники</span><b>4 человека</b></p><p><span>Варианты</span><b>3 диапазона</b></p></div>
        <div className="push-bottom"><button className="primary glow" onClick={() => go("poll")}>Отправить опрос</button></div>
      </main>
    </StepShell>
  );
}

function Poll({ go }: { go: (s: Screen) => void }) {
  const [answers,setAnswers] = useState<Record<number,string>>({0:"yes",1:"yes",2:"no"});
  const options = ["Вт, 19 августа   17:00–21:00","Ср, 20 августа   18:30–23:00","Сб, 23 августа   14:00–20:00"];
  return (
    <div className="screen poll-screen">
      <StatusBar/><Header title="Опрос" onBack={() => go("home")} right={<span className="deadline-pill">до 20:00</span>}/>
      <main className="page-body">
        <div className="event-title"><div><h2>Дабл по боулингу</h2><p className="muted">2 часа   4 участника</p></div></div>
        <div className="privacy-note"><p><b>Календарь проверен</b><small>Ответы можно изменить</small></p></div>
        <div className="answer-list">{options.map((o,i)=><div className="answer-card" key={o}><div><b>{o}</b><small>{i===1?"В календаре свободно":"Есть пересечения"}</small></div><div className="answer-buttons"><button aria-label={`Могу: ${o}`} className={answers[i]==="yes"?"yes":""} onClick={()=>setAnswers({...answers,[i]:"yes"})}>Могу</button><button aria-label={`Не могу: ${o}`} className={answers[i]==="no"?"no":""} onClick={()=>setAnswers({...answers,[i]:"no"})}>Не могу</button></div></div>)}</div>
        <div className="push-bottom"><button className="primary" onClick={() => go("results")}>Отправить ответ</button></div>
      </main><BottomHandle/>
    </div>
  );
}

function Results({ go }: { go: (s: Screen) => void }) {
  return (
    <div className="screen results-screen"><StatusBar/><Header title="Результаты" onBack={()=>go("home")} right={<IconButton label="Ещё">•••</IconButton>}/>
      <main className="page-body">
        <div><h2>Время найдено</h2><p className="muted">Этот вариант подходит всем</p></div>
        <section className="winner-card"><div className="winner-badge">ЛУЧШИЙ ВАРИАНТ</div><h1>Ср, 20 августа</h1><h2>19:00–21:00</h2><div className="availability-score"><strong>4 из 4</strong><span>могут прийти</span></div><div className="mini-avatars large">{people.slice(0,4).map((p,i)=><PersonAvatar key={i} person={p} small/>)}</div></section>
        <section><div className="section-head"><h3>Другие варианты</h3></div><div className="alternative"><span><b>Вт, 19 августа</b><small>18:30–20:30</small></span><strong>3 из 4</strong></div><div className="alternative"><span><b>Сб, 23 августа</b><small>16:00–18:00</small></span><strong>3 из 4</strong></div></section>
        <div className="auto-note"><span>◷</span><p><b>Создадим встречу через 30 минут</b><small>Можно подтвердить сейчас или выбрать другое время</small></p></div>
        <div className="push-bottom"><button className="primary glow" onClick={()=>go("confirmed")}>Подтвердить сейчас</button><button className="secondary">Выбрать другое</button></div>
      </main><BottomHandle/>
    </div>
  );
}

function Confirmed({ go }: { go: (s: Screen) => void }) {
  const participants = [2,3,0,1];
  return (
    <div className="screen confirmed-screen-minimal">
      <div className="confirmed-gradient" style={{background:eventGradient(participants)}}/>
      <StatusBar/><Header right={<IconButton label="Закрыть" onClick={()=>go("home")}>×</IconButton>}/>
      <main className="confirmed-minimal-body">
        <h1>Встреча<br/>создана</h1>
        <section className="confirmed-summary">
          <h2>Дабл по боулингу</h2>
          <div className="confirmed-when"><strong>19:00—21:00</strong><span>Среда, 20 августа</span></div>
          <p>Участники</p>
          <div className="confirmed-participants">{participants.map((index)=><PersonAvatar key={index} person={people[index]} selected />)}</div>
        </section>
      </main>
      <BottomHandle/>
    </div>
  );
}

function Notifications({ go }: { go: (s: Screen) => void }) {
  return <div className="screen"><StatusBar/><Header title="Уведомления" onBack={()=>go("home")} /><main className="page-body"><p className="eyebrow">СЕГОДНЯ</p><button className="notification unread" onClick={()=>go("results")}><span className="notif-icon">◷</span><p><b>Время найдено</b><small>«Дабл по боулингу» — проверь лучший вариант до 20:30</small><em>2 мин</em></p></button><button className="notification unread" onClick={()=>go("poll")}><span className="notif-icon blue-bg">?</span><p><b>Макс зовёт на квиз</b><small>Отметь подходящие варианты до завтра</small><em>18 мин</em></p></button><p className="eyebrow spaced">РАНЕЕ</p><button className="notification"><span className="notif-icon quiet-status" aria-hidden="true"/><p><b>Костя ответил</b><small>Теперь доступны все участники группы</small><em>вчера</em></p></button></main><BottomHandle/></div>;
}

function Calendars({ go, accentIndex }: { go: (s: Screen) => void; accentIndex: number }) {
  const [items,setItems]=useState([{name:"Личный",sub:"iCloud",on:true,color:"pink"},{name:"Работа",sub:"Google",on:true,color:"blue"},{name:"Семья",sub:"iCloud",on:true,color:"green"},{name:"Дни рождения",sub:"Google",on:false,color:"gold"},{name:"Праздники",sub:"Россия",on:false,color:"coral"}]);
  const profileColor = profileColors[accentIndex];
  return <div className="screen"><StatusBar/><Header title="Настройки" onBack={()=>go("home")}/><main className="page-body"><section className="personal-color-card locked-color"><span className="profile-color-swatch" style={{background:profileColor.hex}}/><div><h2>Твой цвет</h2><p className="muted">{profileColor.name} — закреплён за профилем при регистрации</p></div></section><div><h2>Что учитывать</h2><p className="muted">События из выбранных календарей блокируют время<br/>Их названия никому не показываются</p></div><div className="calendar-settings">{items.map((item,i)=><button key={item.name} onClick={()=>setItems(items.map((x,j)=>j===i?{...x,on:!x.on}:x))}><i className={item.color}/><span><b>{item.name}</b><small>{item.sub}</small></span><span className={`switch ${item.on?"on":""}`}><i/></span></button>)}</div><div className="privacy-note"><span>⌁</span><p><b>Приватность по умолчанию</b><small>Друзья видят только свободные окна, а не содержимое событий</small></p></div><button className="secondary add-provider">＋ Подключить ещё календарь</button></main><BottomHandle/></div>;
}

export default function HomePage() {
  const [screen, setScreen] = useState<Screen>("welcome");
  const [accentIndex, setAccentIndex] = useState(0);
  const [profileColorLocked, setProfileColorLocked] = useState(false);
  const accent = profileColors[accentIndex];
  const title = useMemo(() => routes.find(r => r.id === screen)?.label || "Прототип", [screen]);
  const assignProfileColor = () => {
    if (!profileColorLocked) setAccentIndex(Math.floor(Math.random() * profileColors.length));
    setProfileColorLocked(true);
  };
  const render = () => {
    const props = { go: setScreen };
    switch(screen) {
      case "welcome": return <Welcome {...props}/>;
      case "signup": return <Signup {...props} assignProfileColor={assignProfileColor}/>;
      case "connect": return <ConnectCalendars {...props}/>;
      case "home": return <Home {...props}/>;
      case "create": return <CreateMeeting {...props}/>;
      case "people": return <SelectPeople {...props}/>;
      case "windows": return <PickWindows {...props}/>;
      case "deadline": return <Deadline {...props}/>;
      case "poll": return <Poll {...props}/>;
      case "results": return <Results {...props}/>;
      case "confirmed": return <Confirmed {...props}/>;
      case "notifications": return <Notifications {...props}/>;
      case "calendars": return <Calendars {...props} accentIndex={accentIndex}/>;
    }
  };
  return (
    <div className="prototype-shell" style={{"--accent":accent.hex,"--accent-soft":accent.soft,"--accent-rgb":accent.rgb} as CSSProperties}>
      <aside className="prototype-guide">
        <BrandMark/>
        <p className="eyebrow">DRUNA / PROTOTYPE V18</p>
        <h1>Общее время<br/>Без общей суеты</h1>
        <p>Кликабельный сценарий для проверки визуала и ключевой механики опросов</p>
        <nav>{routes.map(r=><button key={r.id} className={screen===r.id?"active":""} onClick={()=>setScreen(r.id)}><span>{String(routes.indexOf(r)+1).padStart(2,"0")}</span>{r.label}</button>)}</nav>
        <div className="guide-note"><b>Сейчас открыт экран</b><span>{title}</span></div>
      </aside>
      <div className="device-wrap"><div className="device">{render()}</div><p className="device-caption">390 × 844 / интерактивный прототип</p></div>
    </div>
  );
}

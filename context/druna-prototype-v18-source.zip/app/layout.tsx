import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Druna — интерактивный прототип",
  description: "Прототип сервиса поиска общего свободного времени.",
  icons: { icon: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ru"><body>{children}</body></html>;
}
